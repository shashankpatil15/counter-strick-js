declare var require: (moduleId: string) => any;
declare var Peer: any;
declare var glMatrix: any;
declare var createjs: any;
